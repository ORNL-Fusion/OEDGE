/* Update routines
*/

#ifndef _dgupdate_h
#define _dgupdate_h

int UpdateLoadedApp(App a,App config);

#endif
