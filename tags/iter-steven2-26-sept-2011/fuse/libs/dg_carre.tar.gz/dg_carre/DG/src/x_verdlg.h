#ifndef _x_verdlg_h
#define _x_verdlg_h

Widget OpenNewPrefsFileDlg(View w,int bUsePrefsFile);
Widget OpenNewVersionDlg(View w,int bUsePrefsFile);

#endif
