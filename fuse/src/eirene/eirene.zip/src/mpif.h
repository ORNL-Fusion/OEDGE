C  Dummy of an include-file needed by MPI
      INTEGER :: MPI_COMM_WORLD
