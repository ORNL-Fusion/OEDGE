int g4getb(iword,iposn,ibit)

register unsigned *iword,*iposn,*ibit;
{
  *ibit= ((*iword >> (32-*iposn))&1);
  return;
}
