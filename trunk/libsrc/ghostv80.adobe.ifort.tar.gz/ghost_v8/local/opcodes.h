/*
* definitions of opcodes for Replay Buffer.
*
*/
 
#define XDRAWLINES 100
#define XDRAWPOINTS 105
#define XDRAWSTRING 110
#define XSETCOLOUR 115
#define XFILLPOLY 120
 
/*
* end
*/
