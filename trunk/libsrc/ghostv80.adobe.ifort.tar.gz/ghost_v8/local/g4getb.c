int g4getb_(iword,iposn,ibit)

register unsigned *iword,*iposn,*ibit;
{
  *ibit= ((*iword >> (32-*iposn))&1);
  return;
}
