#include <cgipw.h>
#include <suntool/gfxsw.h>
#include <pixrect/pixrect.h>
struct pixrect *pr;
Cinrep ivalue;

igtini_()

{

  ivalue.string= "A";
  initialize_lid(IC_STRING,1,&ivalue);
}
iginch_(ich)

  int *ich;

{
  Cawresult stat;
  Cint trigger;

  request_input(IC_STRING,1,-1,&stat,&ivalue,&trigger);
  *ich= *ivalue.string;
}

igtext_(ixpos,iypos,ch)

  int *ixpos,*iypos;
  char *ch;

{
  Ccoor ipos;
  Cchar cha;

  ipos.x= *ixpos;
  ipos.y= *iypos;
  cha= *ch;
  text(&ipos,&cha);
}

int igdeep_()

{
  struct pixwin *mypw;
  struct gfxsubwindow *mine;

  mine= gfxsw_init(0,0);
  mypw= mine->gfx_pixwin;
  pr= mypw->pw_pixrect;
  return(mypw->pw_pixrect->pr_depth);
}

int iopvws_(ipaldp)
  int *ipaldp;

{
  Cint name;
  Cvwsurf device;

  open_cgi();
  NORMAL_VWSURF(device,*ipaldp);
  device.retained= 1;
  device.cmapsize= 128;
  device.cmapname[0]='g';
  open_vws(&name,&device);
  return(name);
}

