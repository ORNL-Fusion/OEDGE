int g4getc_(array,iplace,nbitsc,nchrpw,nchar)

char array[];
register int *iplace,*nchar;
int nbitsc,nchrpw;

{
  *nchar= array[*iplace-1]&255;
  return;
}
