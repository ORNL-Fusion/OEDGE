int g4getk_(iarray,iplace,nbitsc,nchrpw,nchar)

char iarray[];
register int *iplace,*nchar;
int nbitsc,nchrpw;

{
  *nchar= iarray[*iplace-1]&255;
  return;
}
