#include <time.h>
#include <stdio.h>
int enqtim(chtime)
char chtime[];
{
  int i;
  long clock;
  char *timchr;

  clock= time(NULL);
  timchr= ctime(&clock);

  for (i= 0;i<= 7;i++)
    chtime[i]= *(timchr+i+11);
  return;
}
