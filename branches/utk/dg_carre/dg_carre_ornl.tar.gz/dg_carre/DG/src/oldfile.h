/* Read routine for old DG (v0.xx) files
*/

#ifndef _oldfile_h
#define _oldfile_h

int ReadOldDgFile(App a,char* fName,int* errFlags);

#endif
