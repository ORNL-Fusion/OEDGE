#ifndef _topodlg_h
#define _topodlg_h

void CmEditTopology(Widget,XtPointer,XtPointer);
void CmImportTopology(Widget,XtPointer,XtPointer);
void CmUpdateTopology(Widget,XtPointer,XtPointer);

void TopoDlg_NotifyExamine(View w,void* object);

#endif
