/* ToolBox dialogs */

#ifndef _x_toolb_h
#define _x_toolb_h

Widget OpenToolBarDlg(View w);

#endif
