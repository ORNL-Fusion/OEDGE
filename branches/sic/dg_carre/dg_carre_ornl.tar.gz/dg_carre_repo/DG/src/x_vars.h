/* VarsDlg structures & functions
*/

#ifndef _x_vars_h
#define _x_vars_h

Widget OpenVarsEditDlg(View w,void* obj);

Widget OpenInvalidVarsDlg(View w);


#endif
