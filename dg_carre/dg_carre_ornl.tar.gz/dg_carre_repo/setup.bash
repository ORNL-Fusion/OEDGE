#! /bin/bash

export DGCTOP=$PWD

case `uname` in
	"SunOS")
		export OBJECTCODE=SUN
		;;
	"AIX")
		export OBJECTCODE=IBM
		;;
	"OSF1")
		export OBJECTCODE=ALPHA
		;;
	"HP-UX")
		export OBJECTCODE=HP
		;;
	"IRIX")
		export OBJECTCODE=IRIX
		;;
	"Linux")
		export OBJECTCODE=LINUX
		export COMPILER=UNKNOWN
		which pathf90 >& /dev/null
		if [ $? -eq 0 ]; then
			export COMPILER=PATHSCALE
		fi
		which pgf90 >& /dev/null
		if [ $? -eq 0 ]; then
			export COMPILER=PGROUP
		fi
		which gfortran >& /dev/null
		if [ $? -eq 0 ]; then
		    export COMPILER=GFORTRAN
		fi
		;;
	*)
		export OBJECTCODE=UNKNOWN
		;;
esac

if [[ $1 == "" ]]; then
  export DEVICE=iter
else
  export DEVICE=$1
fi
#
# Not sure how useful this will be, but it's at least a placeholder
#
export LESSTIF=`echo $LD_LIBRARY_PATH | sed -e 's/:/\n/g' | awk '/lesstif/ { print $1}'`

alias cddg='cd $DGCTOP/DG/class/$DEVICE'
alias cdcarre='cd $DGCTOP/Carre'

# May need to change divimp
export PATH=$PATH:$DGCTOP/DG:$DGCTOP/DG/equtrn

echo "Compiler set to" $COMPILER


