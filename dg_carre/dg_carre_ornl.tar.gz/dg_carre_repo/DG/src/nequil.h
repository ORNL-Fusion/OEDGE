/* Multiple-zero handling for complex geometries */

#ifndef _nequil_h
#define _nequil_h

int DetectXOPoints(App a);

#endif
