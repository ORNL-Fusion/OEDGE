/* Information and about dialogs */

#ifndef _x_info_h
#define _x_info_h

Widget OpenAboutDlg(View w);
Widget OpenInfoDlg(View w);

#endif
