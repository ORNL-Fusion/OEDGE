/* Mesh dialog boxes */

Widget OpenEditMeshHeaderDlg(View w,Mesh m);
